from setuptools import setup

setup(
    name="Paquete Pre-Entrega N°2 - CoderHouse",
    version="1.0.0",
    author="Jeronimo Gabriel Alo",
    author_email="jeronimoalo2015@gmail.com",
    py_modules=['modulo_preEntrega1', 'modulo_cliente']
)